#!/bin/bash

if [ $1 != "stop" ] && [ $1 != "start" ];then
	echo "请运行参数start or stop | ./install.sh start"
fi


case $1 in

	start )
	/usr/bin/killall yyets_node >/dev/null 2>&1 &
	sleep 1
	./yyets_node >/dev/null 2>&1 &
	sleep 1
	yyets=`ps -ef|grep yyets_node|grep -v grep|grep -v /bin/sh|wc -l`
	if [ $yyets -eq '1' ];then
	echo "yyets_node:程序启动成功"
	fi
	;;
	
	stop )
	/usr/bin/killall yyets_node >/dev/null 2>&1 &
	sleep 1
	yyets=`ps -ef|grep yyets_node|grep -v grep|grep -v /bin/sh|wc -l`
	if [ $yyets -eq '0' ];then
	echo "yyets_node:程序关闭成功"
	fi
	;;
esac


